/**
 * ═══════════════════════════════════════════════════════════════════════════
 * SUPPLY THE SCHOOLS DAO — Backend Server (Port 3004)
 * Decentralized Education Funding — On-Chain Hybrid DAO
 * © 2026 Cyrus Makai Schoonover | Born2Build, LLC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * DOMAINS SERVED:
 *   - supplytheschools.unstoppable (Unstoppable Domain)
 *
 * ENDPOINTS:
 *   POST /api/proposals/submit         ← Submit grant proposal (TRACE-anchored)
 *   GET  /api/proposals                ← List proposals (with vote counts)
 *   GET  /api/proposals/:id            ← Single proposal
 *   POST /api/proposals/:id/vote       ← Cast DAO vote (wallet-idempotent)
 *   GET  /api/ledger                   ← Public on-chain impact ledger
 *   POST /api/ledger/record            ← Record fulfilled grant to ledger
 *   GET  /api/stats/dao                ← DAO statistics
 *   GET  /api/health
 */

'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const express       = require('express');
const cors          = require('cors');
const helmet        = require('helmet');
const compression   = require('compression');
const rateLimit     = require('express-rate-limit');
const morgan        = require('morgan');
const { createClient } = require('@supabase/supabase-js');

const { openTimestampAnchor, sha256, TraceEngine, IDENTITY, WALLETS } = require('../shared/utpl-hub');

const app  = express();
const PORT = process.env.PORT_STS_DAO || 3004;
const supabase = createClient(
  process.env.SUPABASE_URL    || '',
  process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY || ''
);

// In-memory store (replaces DB when Supabase not configured)
const _proposals = new Map();
const _votes     = new Map(); // key: `${proposalId}:${walletAddr}`
const _ledger    = [];

// ── MIDDLEWARE ────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(cors({
  origin: [
    'https://supplytheschools.unstoppable',
    'https://supplytheschools.xyz', 'https://www.supplytheschools.xyz',
    'http://localhost:3000', 'http://localhost:3004',
    process.env.CLOUDFLARE_TUNNEL_ORIGIN || '',
  ].filter(Boolean),
  credentials: true,
}));

const strictLimit = rateLimit({ windowMs: 15 * 60 * 1000, max: 30 });
const voteLimit   = rateLimit({ windowMs: 60 * 60 * 1000, max: 10 });
app.use('/api/', strictLimit);

// ── HEALTH ────────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({
  status: 'OK', service: 'supplytheschools-dao', port: PORT,
  domain: 'supplytheschools.unstoppable',
  supabase: !!process.env.SUPABASE_URL,
  timestamp: new Date().toISOString(),
}));

// ── SUBMIT GRANT PROPOSAL ─────────────────────────────────────────────────
app.post('/api/proposals/submit', async (req, res) => {
  const {
    teacherName, schoolName, schoolEmail, state,
    studentCount, description, amountNeeded, walletAddr,
  } = req.body;

  if (!teacherName || !schoolName || !schoolEmail || !description || !amountNeeded) {
    return res.status(400).json({ error: 'teacherName, schoolName, schoolEmail, description, amountNeeded required' });
  }

  const trace = new TraceEngine();
  trace.transition(0x30, 'PROPOSAL_INIT');

  const proposalId = `PROP-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2,7).toUpperCase()}`;
  const proposalHash = sha256(`${teacherName}|${schoolName}|${schoolEmail}|${description}|${amountNeeded}|${IDENTITY.cert}|${Date.now()}`);

  // Anchor to Bitcoin
  const otsResult = await openTimestampAnchor(proposalHash);
  trace.transition(0x06, 'PROPOSAL_ANCHORED');

  const proposal = {
    id: proposalId,
    teacherName, schoolName, schoolEmail, state,
    studentCount: parseInt(studentCount) || null,
    description,
    amountNeeded: parseFloat(amountNeeded),
    walletAddr: walletAddr || null,
    proposalHash,
    otsCalendar:  otsResult?.calendar,
    otsProofHex:  otsResult?.proofHex,
    traceSessionId: trace.sessionId,
    votesFor:  0,
    votesAgainst: 0,
    status:  'voting_open', // voting_open | approved | rejected | fulfilled
    submittedAt: new Date().toISOString(),
    votingDeadline: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString(), // 72 hours
    fundedAmount: 0,
    cert: IDENTITY.cert,
  };

  // Store — Supabase preferred, in-memory fallback
  if (process.env.SUPABASE_URL) {
    const { data, error } = await supabase.from('dao_proposals').insert({
      id:              proposalId,
      teacher_name:    teacherName,
      school_name:     schoolName,
      school_email:    schoolEmail,
      state,
      student_count:   parseInt(studentCount) || null,
      description,
      amount_needed:   parseFloat(amountNeeded),
      wallet_addr:     walletAddr || null,
      proposal_hash:   proposalHash,
      ots_calendar:    otsResult?.calendar,
      ots_proof_hex:   otsResult?.proofHex,
      trace_session_id: trace.sessionId,
      votes_for:       0,
      votes_against:   0,
      status:          'voting_open',
      voting_deadline: proposal.votingDeadline,
      funded_amount:   0,
    }).select().single();
    if (error) console.error('[STS-DAO] Supabase insert error:', error.message);
  } else {
    _proposals.set(proposalId, proposal);
  }

  trace.transition(0x09, 'PROPOSAL_STORED');

  res.status(201).json({
    success: true,
    proposalId,
    proposalHash,
    otsResult,
    votingDeadline: proposal.votingDeadline,
    status: 'voting_open',
    message: 'Proposal submitted and anchored to Bitcoin. DAO voting opens within 24 hours.',
    cliVerify: `ots verify proposal-${proposalId}.ots`,
    timestamp: new Date().toISOString(),
  });
});

// ── LIST PROPOSALS ────────────────────────────────────────────────────────
app.get('/api/proposals', async (req, res) => {
  const { status = 'voting_open', page = 1, limit = 20 } = req.query;

  if (process.env.SUPABASE_URL) {
    const { data, error, count } = await supabase
      .from('dao_proposals')
      .select('*', { count: 'exact' })
      .eq('status', status)
      .order('submitted_at', { ascending: false })
      .range((page - 1) * limit, page * limit - 1);

    if (error) return res.status(500).json({ error: error.message });
    return res.json({ proposals: data || [], total: count || 0 });
  }

  // In-memory fallback
  const all = [..._proposals.values()].filter(p => !status || p.status === status);
  res.json({ proposals: all.slice(0, parseInt(limit)), total: all.length });
});

// ── SINGLE PROPOSAL ───────────────────────────────────────────────────────
app.get('/api/proposals/:id', async (req, res) => {
  const { id } = req.params;
  if (process.env.SUPABASE_URL) {
    const { data, error } = await supabase.from('dao_proposals').select('*').eq('id', id).single();
    if (error) return res.status(404).json({ error: 'Proposal not found' });
    return res.json(data);
  }
  const p = _proposals.get(id);
  if (!p) return res.status(404).json({ error: 'Proposal not found' });
  res.json(p);
});

// ── CAST VOTE ─────────────────────────────────────────────────────────────
app.post('/api/proposals/:id/vote', voteLimit, async (req, res) => {
  const { id } = req.params;
  const { vote } = req.body; // 'for' | 'against'
  const walletAddr = (req.headers['x-wallet-address'] || req.body.walletAddr || '').toLowerCase();

  if (!walletAddr) return res.status(400).json({ error: 'X-Wallet-Address header or walletAddr body required' });
  if (!['for', 'against'].includes(vote)) return res.status(400).json({ error: 'vote must be "for" or "against"' });

  // Idempotency — one wallet, one vote
  const voteKey = `${id}:${walletAddr}`;
  if (_votes.has(voteKey)) {
    return res.status(409).json({ error: 'Wallet has already voted on this proposal', voteKey });
  }
  _votes.set(voteKey, true);

  const voteHash = sha256(`${id}|${walletAddr}|${vote}|${Date.now()}`);
  const otsResult = await openTimestampAnchor(voteHash);

  // Atomic increment in Supabase
  let updatedProposal = null;
  if (process.env.SUPABASE_URL) {
    const { data, error } = await supabase.rpc('dao_cast_vote', {
      proposal_id_param: id,
      vote_direction:    vote,
      voter_wallet:      walletAddr,
      vote_hash_param:   voteHash,
    });
    if (error) {
      _votes.delete(voteKey); // rollback idempotency
      console.error('[STS-DAO] Vote RPC error:', error.message);
      return res.status(500).json({ error: error.message });
    }
    updatedProposal = data;
  } else {
    // In-memory fallback
    const p = _proposals.get(id);
    if (!p) { _votes.delete(voteKey); return res.status(404).json({ error: 'Proposal not found' }); }
    if (vote === 'for') p.votesFor++; else p.votesAgainst++;
    updatedProposal = p;
  }

  res.json({
    success: true,
    proposalId: id,
    vote,
    voteHash,
    otsResult,
    receipt: { voteKey, wallet: walletAddr, proposalId: id, ts: new Date().toISOString() },
    message: 'Vote recorded, TRACE-anchored, and submitted to Bitcoin calendar.',
  });
});

// ── PUBLIC IMPACT LEDGER ──────────────────────────────────────────────────
app.get('/api/ledger', async (req, res) => {
  const { page = 1, limit = 25 } = req.query;
  if (process.env.SUPABASE_URL) {
    const { data, error } = await supabase
      .from('dao_ledger')
      .select('*')
      .order('fulfilled_at', { ascending: false })
      .range((page - 1) * limit, page * limit - 1);
    if (error) return res.status(500).json({ error: error.message });
    return res.json({ entries: data || [], page: parseInt(page) });
  }
  res.json({ entries: _ledger.slice(0, parseInt(limit)), page: 1 });
});

app.post('/api/ledger/record', async (req, res) => {
  const { proposalId, schoolName, state, supplies, amountUSD, txHash, chain } = req.body;
  if (!proposalId || !schoolName || !amountUSD) {
    return res.status(400).json({ error: 'proposalId, schoolName, amountUSD required' });
  }
  const ledgerHash = sha256(`ledger|${proposalId}|${schoolName}|${amountUSD}|${Date.now()}`);
  const otsResult  = await openTimestampAnchor(ledgerHash);

  const entry = { proposalId, schoolName, state, supplies, amountUSD, txHash, chain, ledgerHash, otsCalendar: otsResult?.calendar, fulfilledAt: new Date().toISOString() };

  if (process.env.SUPABASE_URL) {
    await supabase.from('dao_ledger').insert({ proposal_id: proposalId, school_name: schoolName, state, supplies, amount_usd: parseFloat(amountUSD), tx_hash: txHash, chain, ledger_hash: ledgerHash, ots_calendar: otsResult?.calendar });
    await supabase.from('dao_proposals').update({ status: 'fulfilled', funded_amount: parseFloat(amountUSD) }).eq('id', proposalId);
  } else {
    _ledger.unshift(entry);
  }

  res.status(201).json({ success: true, ledgerHash, otsResult, timestamp: new Date().toISOString() });
});

// ── DAO STATS ─────────────────────────────────────────────────────────────
app.get('/api/stats/dao', async (req, res) => {
  if (!process.env.SUPABASE_URL) {
    return res.json({ totalProposals: _proposals.size, totalLedgerEntries: _ledger.length, wallets: WALLETS });
  }
  const [props, led] = await Promise.allSettled([
    supabase.from('dao_proposals').select('status, amount_needed, student_count', { count: 'exact' }),
    supabase.from('dao_ledger').select('amount_usd'),
  ]);

  const proposals = props.status === 'fulfilled' ? props.value.data || [] : [];
  const ledger    = led.status   === 'fulfilled' ? led.value.data  || [] : [];
  const fulfilled  = proposals.filter(p => p.status === 'fulfilled');
  const totalUSD  = ledger.reduce((s, l) => s + (l.amount_usd || 0), 0);
  const students  = fulfilled.reduce((s, p) => s + (p.student_count || 0), 0);

  res.json({
    totalProposals:    proposals.length,
    votingOpen:        proposals.filter(p => p.status === 'voting_open').length,
    fulfilledGrants:   fulfilled.length,
    totalFundedUSD:    Math.round(totalUSD * 100) / 100,
    studentsReached:   students,
    acceptingChains:   Object.values(WALLETS).map(w => ({ network: w.network, addr: w.addr })),
    fetchedAt:         new Date().toISOString(),
  });
});

// ── SERVER BOOT ───────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════╗
║  SUPPLY THE SCHOOLS DAO — Unstoppable Domain Backend  ║
║  Port: ${PORT}  |  Domain: supplytheschools.unstoppable ║
║  DAO Voting: ACTIVE | BTC Anchoring: ARMED            ║
╚═══════════════════════════════════════════════════════╝`);
});

module.exports = app;
