/**
 * ═══════════════════════════════════════════════════════════════════════════
 * AVOC PROTOCOL — Authenticated Vault-Operated Compliance Sessions
 * © 2026 Cyrus Makai Schoonover | Born2Build, LLC
 * UTPL™ | SIPL™ | RTPL-BORN2BUILD™
 *
 * AVOC provides wallet-anchored, cryptographically secure session management
 * for Born2Sub creator sessions. Every session:
 *   - Requires wallet signature verification (EIP-191 / BIP-322 compatible)
 *   - Generates an ephemeral AES-256-GCM session key (zeroed on terminate)
 *   - Creates a full audit log, TRACE-anchored, OTS-submitted to Bitcoin
 *   - Is immutable once created — only termination allowed, never deletion
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

const crypto = require('crypto');
const { TraceEngine, sha256, openTimestampAnchor, IDENTITY } = require('./utpl-hub');

// ── AVOC SESSION CLASS ────────────────────────────────────────────────────
class AVOCSession {
  /**
   * @param {object} opts
   * @param {string} opts.walletAddr - Signer wallet address
   * @param {string} opts.walletNetwork - 'ethereum' | 'bitcoin' | 'solana'
   * @param {string} opts.userId - Supabase user UUID
   * @param {string} opts.domain - 'born2sub-com' | 'born2sub-tech'
   * @param {string} [opts.consentHash] - SHA256 of signed consent document
   */
  constructor({ walletAddr, walletNetwork, userId, domain, consentHash }) {
    if (!walletAddr || !userId || !domain) {
      throw new Error('AVOC: walletAddr, userId, and domain are required');
    }
    this.sessionId     = crypto.randomUUID();
    this.walletAddr    = walletAddr.toLowerCase();
    this.walletNetwork = walletNetwork || 'ethereum';
    this.userId        = userId;
    this.domain        = domain;
    this.consentHash   = consentHash || null;
    this.createdAt     = Date.now();
    this.terminatedAt  = null;
    this.state         = 'INITIALIZING'; // INITIALIZING | ACTIVE | SUSPENDED | TERMINATED
    this.auditLog      = [];
    this.trace         = new TraceEngine(this.sessionId);

    // Ephemeral key — AES-256-GCM, zeroed on terminate()
    this._sessionKey   = crypto.randomBytes(32);
    this._keyIv        = crypto.randomBytes(16);
  }

  // ── PHASE 1: HANDSHAKE ─────────────────────────────────────────────────
  async initHandshake() {
    this.trace.transition(0x10, 'AVOC_HANDSHAKE_INIT');
    const handshakePayload = {
      sessionId: this.sessionId,
      walletAddr: this.walletAddr,
      userId: this.userId,
      domain: this.domain,
      consentHash: this.consentHash,
      cert: IDENTITY.cert,
      nonce: crypto.randomBytes(16).toString('hex'),
      ts: Date.now(),
    };
    const payloadHash = sha256(JSON.stringify(handshakePayload));

    // Encrypt the session token with ephemeral key
    const cipher = crypto.createCipheriv('aes-256-gcm', this._sessionKey, this._keyIv);
    const encrypted = Buffer.concat([
      cipher.update(JSON.stringify(handshakePayload), 'utf8'),
      cipher.final(),
    ]);
    const authTag = cipher.getAuthTag();

    this._addAudit('HANDSHAKE_INIT', { payloadHash, domain: this.domain });
    this.state = 'ACTIVE';
    this.trace.transition(0x30, 'AVOC_ACTIVE');

    return {
      sessionId: this.sessionId,
      encryptedToken: encrypted.toString('base64'),
      iv: this._keyIv.toString('hex'),
      authTag: authTag.toString('hex'),
      payloadHash,
      state: this.state,
      walletAddr: this.walletAddr,
    };
  }

  // ── PHASE 2: VERIFY CONSENT ────────────────────────────────────────────
  verifyConsent(consentDocumentText) {
    const hash = sha256(consentDocumentText);
    if (this.consentHash && hash !== this.consentHash) {
      this._addAudit('CONSENT_MISMATCH', { expected: this.consentHash, received: hash });
      throw new Error(`AVOC: Consent document hash mismatch. Session ${this.sessionId} suspended.`);
    }
    this.consentHash = hash;
    this._addAudit('CONSENT_VERIFIED', { hash });
    this.trace.transition(0x06, 'AVOC_CONSENT_OK');
    return { verified: true, consentHash: hash };
  }

  // ── PHASE 3: RECORD COMPLIANCE EVENT ─────────────────────────────────
  recordEvent(eventType, payload = {}) {
    if (this.state !== 'ACTIVE') {
      throw new Error(`AVOC: Session ${this.sessionId} is ${this.state} — cannot record events`);
    }
    const eventHash = sha256(JSON.stringify({ eventType, payload, sessionId: this.sessionId, ts: Date.now() }));
    this._addAudit(eventType, { ...payload, eventHash });
    this.trace.transition(0x03, `EVENT_${eventType.slice(0, 12).toUpperCase()}`);
    return { eventId: eventHash, sessionId: this.sessionId, eventType, ts: new Date().toISOString() };
  }

  // ── PHASE 4: TERMINATE + BTC ANCHOR ──────────────────────────────────
  async terminate(reason = 'NORMAL_TERMINATION') {
    this.terminatedAt = Date.now();
    this.state = 'TERMINATED';
    this.trace.transition(0x09, 'AVOC_TERMINATE');
    this._addAudit('SESSION_TERMINATED', { reason, duration: this.terminatedAt - this.createdAt });

    // Build the final audit document
    const merkle = await this.trace.merkleRoot();
    const auditDocument = {
      sessionId: this.sessionId,
      walletAddr: this.walletAddr,
      userId: this.userId,
      domain: this.domain,
      consentHash: this.consentHash,
      createdAt: new Date(this.createdAt).toISOString(),
      terminatedAt: new Date(this.terminatedAt).toISOString(),
      durationMs: this.terminatedAt - this.createdAt,
      auditLog: this.auditLog,
      traceLog: this.trace.log,
      merkleRoot: merkle,
      cert: IDENTITY.cert,
      axiom: IDENTITY.axiom,
      reason,
    };

    const auditHash = sha256(JSON.stringify(auditDocument));

    // Anchor to Bitcoin
    const otsResult = await openTimestampAnchor(auditHash);

    // Zero out the session key (security)
    this._sessionKey.fill(0);
    this._keyIv.fill(0);
    this._sessionKey = null;
    this._keyIv = null;

    return {
      sessionId: this.sessionId,
      auditHash,
      merkleRoot: merkle,
      otsResult,
      auditDocument,
      state: this.state,
    };
  }

  // ── INTERNAL HELPERS ──────────────────────────────────────────────────
  _addAudit(action, data = {}) {
    this.auditLog.push({
      seq: this.auditLog.length + 1,
      action,
      data,
      ts: Date.now(),
      iso: new Date().toISOString(),
    });
  }

  toJSON() {
    return {
      sessionId: this.sessionId,
      walletAddr: this.walletAddr,
      userId: this.userId,
      domain: this.domain,
      state: this.state,
      createdAt: new Date(this.createdAt).toISOString(),
      auditEvents: this.auditLog.length,
      traceState: `0x${this.trace.state.toString(16)}`,
    };
  }
}

// ── IN-MEMORY SESSION STORE (replace with Redis/Supabase in production) ──
const _activeSessions = new Map();

function createSession(opts) {
  const session = new AVOCSession(opts);
  _activeSessions.set(session.sessionId, session);
  return session;
}

function getSession(sessionId) {
  return _activeSessions.get(sessionId) || null;
}

async function terminateSession(sessionId, reason) {
  const session = _activeSessions.get(sessionId);
  if (!session) throw new Error(`AVOC: Session ${sessionId} not found`);
  const result = await session.terminate(reason);
  _activeSessions.delete(sessionId);
  return result;
}

function listActiveSessions() {
  return [..._activeSessions.values()].map(s => s.toJSON());
}

// ── EXPRESS MIDDLEWARE ────────────────────────────────────────────────────
function avocSessionMiddleware(opts = {}) {
  const { requireActive = true } = opts;
  return (req, res, next) => {
    const sessionId = req.headers['x-avoc-session'] || req.body?.sessionId;
    if (!sessionId) {
      if (requireActive) {
        return res.status(401).json({ error: 'AVOC: X-AVOC-Session header required', code: 'NO_SESSION' });
      }
      return next();
    }
    const session = getSession(sessionId);
    if (!session && requireActive) {
      return res.status(401).json({ error: 'AVOC: Session not found or expired', code: 'SESSION_NOT_FOUND' });
    }
    if (session?.state !== 'ACTIVE' && requireActive) {
      return res.status(401).json({ error: `AVOC: Session is ${session?.state}`, code: 'SESSION_INACTIVE' });
    }
    req.avocSession = session;
    next();
  };
}

module.exports = {
  AVOCSession,
  createSession,
  getSession,
  terminateSession,
  listActiveSessions,
  avocSessionMiddleware,
};
