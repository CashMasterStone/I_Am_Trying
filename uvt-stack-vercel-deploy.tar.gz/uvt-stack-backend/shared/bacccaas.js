/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BACCCaaS — Born2Build Adult Content Creator Compliance as a Service
 * Blockchain Anchored Compliance, Content Classification as a Service
 * © 2026 Cyrus Makai Schoonover | Born2Build, LLC
 * UTPL™ | SIPL™ | DomCode ISA
 *
 * SEVEN COMPLIANCE GATES (run in sequence, all must pass):
 *   GATE_1: §2257  — Performer age/identity verification records
 *   GATE_2: SESTA  — SESTA-FOSTA trafficking deterrence
 *   GATE_3: CONSENT — Informed, documented consent verification
 *   GATE_4: COPPA  — No minors (COPPA, 15 U.S.C. §6501)
 *   GATE_5: TRACE  — Provenance chain integrity
 *   GATE_6: AVOC   — Wallet-anchored session validity
 *   GATE_7: UTPL   — Sovereign license compliance
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

const { TraceEngine, sha256, openTimestampAnchor, IDENTITY } = require('./utpl-hub');

// ── GATE DEFINITIONS ──────────────────────────────────────────────────────
const GATES = {
  GATE_1_2257: {
    id: 'GATE_1_2257',
    statute: '18 U.S.C. §2257 / 28 C.F.R. §75',
    description: 'Performer age verification & record-keeping',
    required: ['performerId', 'dob', 'legalName', 'documentType', 'documentHash'],
    criticalFailure: true,
  },
  GATE_2_SESTA: {
    id: 'GATE_2_SESTA',
    statute: 'SESTA-FOSTA (47 U.S.C. §230 / 18 U.S.C. §1591)',
    description: 'Sex trafficking deterrence documentation',
    required: ['platformId', 'contentType', 'consentVerified'],
    criticalFailure: true,
  },
  GATE_3_CONSENT: {
    id: 'GATE_3_CONSENT',
    statute: '18 U.S.C. §2257(a)(3)',
    description: 'Informed, documented consent verification',
    required: ['consentHash', 'consentDate', 'consentVersion'],
    criticalFailure: true,
  },
  GATE_4_COPPA: {
    id: 'GATE_4_COPPA',
    statute: '15 U.S.C. §6501 (COPPA)',
    description: 'No minors — under-13 protection',
    required: ['verifiedAdult', 'ageVerificationMethod'],
    criticalFailure: true,
  },
  GATE_5_TRACE: {
    id: 'GATE_5_TRACE',
    statute: 'UTPL™ DomCode ISA §TRACE',
    description: 'Provenance chain integrity',
    required: ['traceSessionId'],
    criticalFailure: false,
  },
  GATE_6_AVOC: {
    id: 'GATE_6_AVOC',
    statute: 'AVOC Protocol v1.0',
    description: 'Wallet-anchored session validity',
    required: ['walletAddr'],
    criticalFailure: false,
  },
  GATE_7_UTPL: {
    id: 'GATE_7_UTPL',
    statute: 'UTPL™ / SIPL™ v1.0',
    description: 'Sovereign license compliance',
    required: [],
    criticalFailure: false,
  },
};

// ── INDIVIDUAL GATE VALIDATORS ────────────────────────────────────────────
async function validate2257(data) {
  const missing = GATES.GATE_1_2257.required.filter(f => !data[f]);
  if (missing.length > 0) {
    return { pass: false, reason: `Missing required §2257 fields: ${missing.join(', ')}`, missing };
  }
  // Validate DOB format and age >= 18
  const dob = new Date(data.dob);
  if (isNaN(dob.getTime())) return { pass: false, reason: 'Invalid date of birth format' };
  const ageMs = Date.now() - dob.getTime();
  const ageYears = ageMs / (1000 * 60 * 60 * 24 * 365.25);
  if (ageYears < 18) return { pass: false, reason: '§2257 VIOLATION: Performer under 18' };
  if (ageYears > 100) return { pass: false, reason: '§2257: DOB appears invalid (age > 100)' };
  return {
    pass: true,
    performerId: data.performerId,
    verifiedAge: Math.floor(ageYears),
    documentType: data.documentType,
    documentHash: data.documentHash,
  };
}

async function validateSESTA(data) {
  const missing = GATES.GATE_2_SESTA.required.filter(f => !data[f]);
  if (missing.length > 0) return { pass: false, reason: `Missing SESTA-FOSTA fields: ${missing.join(', ')}`, missing };
  if (!data.consentVerified) return { pass: false, reason: 'SESTA-FOSTA: Consent not verified' };
  // Check for trafficking risk indicators (platform-level)
  const riskFlags = [];
  if (data.exchangeForValue && !data.taxDocumentation) riskFlags.push('PAYMENT_WITHOUT_TAX_DOC');
  if (data.thirdPartyArranged && !data.agencyVerification) riskFlags.push('UNVERIFIED_THIRD_PARTY');
  return {
    pass: true,
    platformId: data.platformId,
    contentType: data.contentType,
    riskFlags,
    deterrenceDocumented: true,
  };
}

async function validateConsent(data) {
  const missing = GATES.GATE_3_CONSENT.required.filter(f => !data[f]);
  if (missing.length > 0) return { pass: false, reason: `Missing consent fields: ${missing.join(', ')}`, missing };
  const consentDate = new Date(data.consentDate);
  if (isNaN(consentDate.getTime())) return { pass: false, reason: 'Invalid consent date' };
  // Consent must not be pre-dated beyond 30 days from now
  const daysDiff = (Date.now() - consentDate.getTime()) / (1000 * 60 * 60 * 24);
  if (daysDiff > 365) return { pass: false, reason: 'Consent document older than 1 year — renewal required' };
  return {
    pass: true,
    consentHash: data.consentHash,
    consentDate: consentDate.toISOString(),
    consentVersion: data.consentVersion,
    daysOld: Math.floor(daysDiff),
  };
}

async function validateCOPPA(data) {
  if (!data.verifiedAdult) return { pass: false, reason: 'COPPA: Adult status not verified' };
  const validMethods = ['government_id', 'credit_card', 'notarized_doc', 'ai_facial_estimate'];
  if (!validMethods.includes(data.ageVerificationMethod)) {
    return { pass: false, reason: `COPPA: Invalid verification method. Must be one of: ${validMethods.join(', ')}` };
  }
  return { pass: true, method: data.ageVerificationMethod };
}

async function validateTRACE(data) {
  if (!data.traceSessionId) return { pass: false, reason: 'TRACE: No sessionId provided' };
  // Basic UUID format check
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuidRegex.test(data.traceSessionId)) return { pass: false, reason: 'TRACE: Invalid session ID format' };
  return { pass: true, traceSessionId: data.traceSessionId };
}

async function validateAVOC(data) {
  if (!data.walletAddr) return { pass: false, reason: 'AVOC: No wallet address' };
  // Basic format validation
  const isEVM  = /^0x[a-fA-F0-9]{40}$/.test(data.walletAddr);
  const isBTC  = /^(1|3|bc1)[a-zA-Z0-9]{25,62}$/.test(data.walletAddr);
  const isSOL  = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(data.walletAddr);
  if (!isEVM && !isBTC && !isSOL) {
    return { pass: false, reason: 'AVOC: Wallet address format unrecognized (expected EVM/BTC/SOL)' };
  }
  return { pass: true, walletAddr: data.walletAddr, network: isEVM ? 'EVM' : isBTC ? 'Bitcoin' : 'Solana' };
}

async function validateUTPL(data) {
  // UTPL gate — check license acknowledgment in request
  const utplAck = data.utplAcknowledged || data.licenseAccepted;
  if (!utplAck) {
    return { pass: false, reason: 'UTPL: License acknowledgment required', note: 'Include utplAcknowledged:true in request' };
  }
  return {
    pass: true,
    license: 'UTPL™ v1.0 | SIPL™ v1.0 | RTPL-BORN2BUILD™',
    cert: IDENTITY.cert,
  };
}

// ── MASTER GATE RUNNER ────────────────────────────────────────────────────
async function runGates(data, { gates = Object.keys(GATES), anchorOnPass = true } = {}) {
  const trace = new TraceEngine();
  trace.transition(0x10, 'BACCCAAS_INIT');

  const results = {};
  let overallPass = true;
  let criticalFail = false;

  const gateValidators = {
    GATE_1_2257: validate2257,
    GATE_2_SESTA: validateSESTA,
    GATE_3_CONSENT: validateConsent,
    GATE_4_COPPA: validateCOPPA,
    GATE_5_TRACE: validateTRACE,
    GATE_6_AVOC: validateAVOC,
    GATE_7_UTPL: validateUTPL,
  };

  for (const gateId of gates) {
    const gate = GATES[gateId];
    const validator = gateValidators[gateId];
    if (!gate || !validator) continue;

    try {
      const result = await validator(data);
      results[gateId] = {
        ...gate,
        ...result,
        validatedAt: new Date().toISOString(),
      };
      trace.transition(result.pass ? 0x03 : 0x02, `GATE_${gateId.slice(-4)}_${result.pass ? 'PASS' : 'FAIL'}`);
      if (!result.pass) {
        overallPass = false;
        if (gate.criticalFailure) criticalFail = true;
      }
    } catch (err) {
      results[gateId] = { pass: false, reason: `Gate error: ${err.message}`, error: true };
      overallPass = false;
      if (gate.criticalFailure) criticalFail = true;
    }
  }

  trace.transition(0x09, overallPass ? 'BACCCAAS_PASS' : 'BACCCAAS_FAIL');
  const merkle = await trace.merkleRoot();
  const complianceHash = sha256(JSON.stringify({ results, merkle, ts: Date.now() }));

  let otsResult = null;
  if (anchorOnPass && overallPass) {
    otsResult = await openTimestampAnchor(complianceHash);
  }

  return {
    pass: overallPass,
    criticalFail,
    complianceHash,
    merkleRoot: merkle,
    traceSessionId: trace.sessionId,
    timestamp: new Date().toISOString(),
    gates: results,
    otsResult,
    determination: overallPass
      ? 'COMPLIANT — All gates passed. Bitcoin-anchored.'
      : criticalFail
        ? 'CRITICAL VIOLATION — Federal compliance gate failed.'
        : 'NON-COMPLIANT — Advisory gates failed.',
  };
}

// ── EXPRESS MIDDLEWARE FACTORY ────────────────────────────────────────────
/**
 * Creates an Express middleware that runs BACCCaaS compliance gates.
 * @param {object} opts
 * @param {string[]} [opts.gates] - Gate IDs to run (default: all 7)
 * @param {function} [opts.dataExtractor] - fn(req) => data object for gates
 * @param {boolean} [opts.blockOnFail] - Send 403 if gates fail (default: true)
 * @param {boolean} [opts.anchorOnPass] - BTC anchor on pass (default: true for prod)
 */
function bacccaasMiddleware(opts = {}) {
  const {
    gates = Object.keys(GATES),
    dataExtractor = (req) => ({ ...req.body, ...req.query, walletAddr: req.headers['x-wallet-address'] }),
    blockOnFail = true,
    anchorOnPass = process.env.NODE_ENV === 'production',
  } = opts;

  return async (req, res, next) => {
    try {
      const data = dataExtractor(req);
      const result = await runGates(data, { gates, anchorOnPass });
      req.bacccaas = result;

      if (!result.pass && blockOnFail) {
        return res.status(403).json({
          error: 'BACCCaaS Compliance Gate Failed',
          determination: result.determination,
          criticalFail: result.criticalFail,
          failures: Object.fromEntries(
            Object.entries(result.gates)
              .filter(([, v]) => !v.pass)
              .map(([k, v]) => [k, { statute: v.statute, reason: v.reason }])
          ),
          complianceHash: result.complianceHash,
        });
      }
      next();
    } catch (err) {
      console.error('[BACCCaaS] Middleware error:', err);
      if (blockOnFail) {
        return res.status(500).json({ error: 'BACCCaaS internal error', message: err.message });
      }
      next();
    }
  };
}

// ── QUICK CHECK (for health/status endpoints) ────────────────────────────
async function quickHealthCheck() {
  return {
    service: 'BACCCaaS',
    version: '1.0',
    gates: Object.values(GATES).map(g => ({
      id: g.id,
      statute: g.statute,
      critical: g.criticalFailure,
    })),
    cert: IDENTITY.cert,
    timestamp: new Date().toISOString(),
  };
}

module.exports = {
  GATES,
  runGates,
  bacccaasMiddleware,
  quickHealthCheck,
  validate2257,
  validateSESTA,
  validateConsent,
  validateCOPPA,
  validateTRACE,
  validateAVOC,
  validateUTPL,
};
