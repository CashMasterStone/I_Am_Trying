/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BORN2SUB.TECH — Backend Server (Port 3002)
 * UTPL Sovereign Compliance Terminal — Multi-Domain Verification
 * © 2026 Cyrus Makai Schoonover | Born2Build, LLC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * DOMAINS SERVED:
 *   - born2sub.tech (primary — general compliance hub)
 *
 * ENDPOINTS:
 *   POST /api/query/sovereign          ← Full UTPL AI + OTS + USPTO session
 *   GET  /api/ip/portfolio             ← Born2Build IP registry
 *   POST /api/ip/register              ← Register new IP asset (SHA256 + OTS)
 *   POST /api/ip/search/uspto          ← Live USPTO prior art search
 *   GET  /api/wallets/all              ← All wallet balances (multi-chain)
 *   GET  /api/legislation/status       ← State legislature monitoring feed
 *   POST /api/anchor/document          ← Anchor any document hash to BTC
 *   WS   /ws/terminal                  ← Live DomCode terminal stream
 *   GET  /api/health
 */

'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const express       = require('express');
const cors          = require('cors');
const helmet        = require('helmet');
const compression   = require('compression');
const rateLimit     = require('express-rate-limit');
const morgan        = require('morgan');
const http          = require('http');
const { WebSocketServer } = require('ws');
const { createClient } = require('@supabase/supabase-js');

const { runSovereignSession, searchUSPTO, openTimestampAnchor, getBtcBalance, getBaseBalance, claudeAnalyze, sha256, TraceEngine, IDENTITY, WALLETS } = require('../shared/utpl-hub');

const app    = express();
const server = http.createServer(app);
const PORT   = process.env.PORT_B2S_TECH || 3002;

const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY || ''
);

// ── IP PORTFOLIO (Born2Build) ─────────────────────────────────────────────
const IP_PORTFOLIO = [
  { id: 'MFHST', name: 'MFHST — Meta-Forensic Harvesting Substrate Technology', type: 'patent', status: 'Provisional Filed', date: '2025-10-16', statute: '35 U.S.C. §111(b)', notes: '14 inventions — IndividuationPatent_251016_140114.docx' },
  { id: 'LUMEN', name: 'Lumen ISA / Lumen Assembly Language', type: 'trade_secret', status: 'Trade Secret + Copyright', date: '2025-09', statute: '17 U.S.C. §102', notes: 'NOT LLVM — distinct original architecture' },
  { id: 'TRACE', name: 'TRACE Provenance State Machine (0x0→0x3→0x6→0x9)', type: 'patent', status: 'Patent Pending', date: '2025-10', statute: '35 U.S.C. §101', notes: 'Deterministic cert-seeded state machine' },
  { id: 'DSMCALLE', name: 'DSMCALLE Framework — 42+ Domain Assembly DAGs', type: 'patent', status: 'Patent Pending', date: '2025-10', statute: '35 U.S.C. §101', notes: 'Domain-Specific Machine Code Assembly Language' },
  { id: 'ZTBA', name: 'Zero-True Binary Axiom (0=Coherence/Truth)', type: 'copyright', status: 'Copyright', date: '2025-01', statute: '17 U.S.C. §102', notes: 'Original philosophical-computational axiom' },
  { id: 'ACCCAAS', name: 'ACCCaaS / DomCode ISA', type: 'copyright', status: 'Copyright + Patent Pending', date: '2025-09', statute: '17 U.S.C. §102 / 35 U.S.C. §101', notes: '18 U.S.C. §2257 compliance automation' },
  { id: 'UTPL', name: 'UTPL™ / SIPL™ / RTPL-BORN2BUILD™', type: 'trademark', status: 'Trademark', date: '2025', statute: '15 U.S.C. §1051', notes: 'Sovereign license framework' },
  { id: 'B2SX', name: 'Born2Sub.X Sovereign Infrastructure', type: 'trademark', status: 'Trademark + Copyright', date: '2025', statute: '15 U.S.C. §1051 / 17 U.S.C. §102', notes: 'Web3 deployment stack' },
];

const STATE_LEGISLATION = [
  { state: 'TX', law: 'TRAIGA', title: 'Texas Responsible AI Governance Act', relevance: 'AI compliance, content moderation', url: 'https://capitol.texas.gov/', priority: 'HIGH', status: 'ACTIVE' },
  { state: 'CA', law: 'AB 2013 / SB 1047', title: 'AI Transparency + Foundation Model Safety', relevance: 'AI training data disclosure', url: 'https://leginfo.legislature.ca.gov/', priority: 'HIGH', status: 'ACTIVE' },
  { state: 'NV', law: 'SB 398 / NRS 719', title: 'Blockchain Records + Electronic Transactions', relevance: 'On-chain records as legal evidence', url: 'https://www.leg.state.nv.us/', priority: 'HIGH', status: 'ACTIVE' },
  { state: 'WY', law: 'SF 38 / DAO LLC Act', title: 'DAO LLC Act + Digital Asset Legislation', relevance: 'Sovereign entity, token assets', url: 'https://www.wyoleg.gov/', priority: 'HIGH', status: 'ACTIVE' },
  { state: 'FED', law: '18 USC §2257 / SESTA-FOSTA', title: 'Adult Content Record-Keeping', relevance: 'ACCCaaS compliance core — CRITICAL', url: 'https://www.law.cornell.edu/', priority: 'CRITICAL', status: 'ENFORCED' },
  { state: 'FED', law: '35 USC / 17 USC', title: 'Patent Act / Copyright Act', relevance: 'MFHST, Lumen ISA, TRACE', url: 'https://www.uspto.gov/', priority: 'HIGH', status: 'ACTIVE' },
  { state: 'EU',  law: 'MiCA + EU AI Act', title: 'Markets in Crypto-Assets + AI Regulation', relevance: 'If EU expansion', url: 'https://eur-lex.europa.eu/', priority: 'MEDIUM', status: 'ACTIVE' },
];

// ── MIDDLEWARE ────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(cors({
  origin: [
    'https://born2sub.tech', 'https://www.born2sub.tech',
    'http://localhost:3000', 'http://localhost:3002',
    process.env.CLOUDFLARE_TUNNEL_ORIGIN || '',
  ].filter(Boolean),
  credentials: true,
}));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, max: 60 }));

// ── HEALTH ────────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({
  status: 'OK', service: 'born2sub-tech', port: PORT,
  cert: IDENTITY.cert, axiom: IDENTITY.axiom,
  websocket: true, timestamp: new Date().toISOString(),
}));

// ── SOVEREIGN SESSION (AI + OTS + USPTO simultaneously) ──────────────────
app.post('/api/query/sovereign', async (req, res) => {
  const { query, domain = 'ip', jurisdictions = [] } = req.body;
  if (!query) return res.status(400).json({ error: 'query required' });
  const result = await runSovereignSession({ query, domain, jurisdictions });
  res.json(result);
});

// ── IP PORTFOLIO ──────────────────────────────────────────────────────────
app.get('/api/ip/portfolio', (req, res) => {
  res.json({ portfolio: IP_PORTFOLIO, cert: IDENTITY.cert, fetchedAt: new Date().toISOString() });
});

app.post('/api/ip/register', async (req, res) => {
  const { assetName, assetType, description, ownerWallet } = req.body;
  if (!assetName || !assetType) return res.status(400).json({ error: 'assetName and assetType required' });

  const assetHash = sha256(`${assetName}|${assetType}|${description || ''}|${IDENTITY.cert}|${Date.now()}`);
  const otsResult = await openTimestampAnchor(assetHash);

  let dbRecord = null;
  if (process.env.SUPABASE_URL) {
    const { data } = await supabase.from('ip_registry').insert({
      asset_name: assetName, asset_type: assetType,
      description, owner_wallet: ownerWallet,
      asset_hash: assetHash, ots_calendar: otsResult?.calendar,
      ots_proof_hex: otsResult?.proofHex, cert: IDENTITY.cert,
      license: 'UTPL™ | SIPL™ | RTPL-BORN2BUILD™',
    }).select().single();
    dbRecord = data;
  }

  res.status(201).json({
    success: true, assetName, assetType, assetHash,
    otsResult, license: 'UTPL™ | SIPL™ | RTPL-BORN2BUILD™',
    cert: IDENTITY.cert,
    dbRecord: dbRecord ? { id: dbRecord.id } : null,
    timestamp: new Date().toISOString(),
  });
});

// ── USPTO PRIOR ART SEARCH ────────────────────────────────────────────────
app.post('/api/ip/search/uspto', async (req, res) => {
  const { query, perPage = 5 } = req.body;
  if (!query) return res.status(400).json({ error: 'query required' });
  const result = await searchUSPTO(query, { perPage });
  res.json({ ...result, searchedAt: new Date().toISOString() });
});

// ── MULTI-WALLET BALANCES ────────────────────────────────────────────────
app.get('/api/wallets/all', async (req, res) => {
  const [btc, base] = await Promise.allSettled([
    getBtcBalance(WALLETS.BTC_PERSONAL.addr),
    getBaseBalance(WALLETS.BASE.addr),
  ]);
  res.json({
    BTC_PERSONAL: btc.status  === 'fulfilled' ? btc.value  : null,
    BASE:         base.status === 'fulfilled' ? base.value : null,
    wallets:      WALLETS,
    goMiningNFT:  { id: '966fa915-7eed-41b2-a343-e4d88abe1e87', tokenId: '#420621', power: '1 TH', efficiency: '15 W/TH', url: 'https://app.gomining.com/nft/view/966fa915-7eed-41b2-a343-e4d88abe1e87' },
    fetchedAt:    new Date().toISOString(),
  });
});

// ── LEGISLATION STATUS ────────────────────────────────────────────────────
app.get('/api/legislation/status', (req, res) => {
  res.json({ legislation: STATE_LEGISLATION, fetchedAt: new Date().toISOString() });
});

// ── DOCUMENT ANCHOR ───────────────────────────────────────────────────────
app.post('/api/anchor/document', async (req, res) => {
  const { content, label } = req.body;
  if (!content) return res.status(400).json({ error: 'content required' });
  const hash = sha256(content);
  const otsResult = await openTimestampAnchor(hash);
  res.json({ hash, label: label || 'document', otsResult, cert: IDENTITY.cert, timestamp: new Date().toISOString() });
});

// ── WEBSOCKET TERMINAL ────────────────────────────────────────────────────
const wss = new WebSocketServer({ server, path: '/ws/terminal' });

wss.on('connection', (ws, req) => {
  const trace = new TraceEngine();
  trace.transition(0x30, 'WS_CONNECT');

  ws.send(JSON.stringify({
    type: 'BANNER',
    data: `BORN2SUB.TECH — UTPL SOVEREIGN TERMINAL\n© 2026 ${IDENTITY.name} | Born2Build, LLC\nCERT: ${IDENTITY.cert}\n"${IDENTITY.axiom}"\n\nType {"command":"<your query>","domain":"<ip|fraud|tax|blockchain>"}\n`,
  }));

  ws.on('message', async (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); }
    catch { ws.send(JSON.stringify({ type: 'ERROR', data: 'Invalid JSON' })); return; }

    const { command, domain = 'ip', jurisdictions = [] } = msg;
    if (!command) return;

    ws.send(JSON.stringify({ type: 'TRACE', data: `TRACE ${trace.transition(0x60, 'WS_QUERY').next} — processing: "${command.slice(0,60)}"` }));
    ws.send(JSON.stringify({ type: 'STATUS', data: 'SOVEREIGN_SESSION_INIT → AI + OTS + USPTO firing simultaneously...' }));

    try {
      const result = await runSovereignSession({ query: command, domain, jurisdictions });
      trace.transition(0x09, 'WS_RESULT');

      ws.send(JSON.stringify({ type: 'RESULT', data: result.ai?.analysis || result.ai?.error || 'No AI analysis (ANTHROPIC_API_KEY not set)' }));
      ws.send(JSON.stringify({ type: 'ANCHOR', data: result.ots?.success ? `₿ ANCHORED → ${result.ots.calendar} | Hash: ${result.queryHash.slice(0,16)}…` : `Hash: ${result.queryHash.slice(0,16)}… (submit manually: ots stamp)` }));
      ws.send(JSON.stringify({ type: 'MERKLE', data: `Merkle: ${result.merkleRoot?.slice(0,32)}…` }));
    } catch (err) {
      ws.send(JSON.stringify({ type: 'ERROR', data: err.message }));
    }
  });

  ws.on('close', () => trace.transition(0x00, 'WS_DISCONNECT'));
});

// ── SERVER BOOT ───────────────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════╗
║  BORN2SUB.TECH — Sovereign Compliance Terminal        ║
║  Port: ${PORT}  |  WebSocket: ws://localhost:${PORT}/ws/terminal ║
║  Domains: born2sub.tech                               ║
╚═══════════════════════════════════════════════════════╝`);
});

module.exports = app;
