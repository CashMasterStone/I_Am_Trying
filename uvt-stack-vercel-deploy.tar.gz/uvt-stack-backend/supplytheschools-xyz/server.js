/**
 * ═══════════════════════════════════════════════════════════════════════════
 * SUPPLY THE SCHOOLS — Backend Server (Port 3003)
 * Education Supply Platform — Teacher Requests + Stripe + Grant Management
 * © 2026 Cyrus Makai Schoonover | Born2Build, LLC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * DOMAINS SERVED:
 *   - supplytheschools.xyz (primary)
 *   - supplytheschools.tech, supplytheschools.online (IONOS)
 *
 * ENDPOINTS:
 *   POST /api/requests/submit         ← Teacher classroom request
 *   GET  /api/requests                ← All open requests (paginated)
 *   GET  /api/requests/:id            ← Single request
 *   POST /api/requests/:id/fulfill    ← Mark fulfilled (admin)
 *   POST /api/donations/stripe/intent ← Create Stripe PaymentIntent
 *   POST /api/donations/stripe/webhook ← Stripe webhook handler
 *   POST /api/donations/crypto/record ← Record crypto donation
 *   GET  /api/impact/stats            ← Public impact numbers
 *   GET  /api/health
 */

'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const express       = require('express');
const cors          = require('cors');
const helmet        = require('helmet');
const compression   = require('compression');
const rateLimit     = require('express-rate-limit');
const morgan        = require('morgan');
const { createClient } = require('@supabase/supabase-js');

const { openTimestampAnchor, sha256, IDENTITY, WALLETS } = require('../shared/utpl-hub');

let stripe = null;
if (process.env.STRIPE_SECRET_KEY) {
  stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
}

const app  = express();
const PORT = process.env.PORT_STS_XYZ || 3003;
const supabase = createClient(
  process.env.SUPABASE_URL    || '',
  process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY || ''
);

// ── SUPPLY CATEGORIES ─────────────────────────────────────────────────────
const SUPPLY_CATEGORIES = [
  'core_supplies', 'technology', 'books_reading', 'stem_science',
  'arts_creativity', 'health_nutrition', 'teacher_tools', 'special_needs',
];

// ── MIDDLEWARE ────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(morgan('combined'));

// Stripe webhook needs raw body — parse it before JSON middleware
app.post('/api/donations/stripe/webhook', express.raw({ type: 'application/json' }), handleStripeWebhook);

app.use(express.json({ limit: '10mb' }));
app.use(cors({
  origin: [
    'https://supplytheschools.xyz', 'https://www.supplytheschools.xyz',
    'https://supplytheschools.tech', 'https://supplytheschools.online',
    'http://localhost:3000', 'http://localhost:3003',
    process.env.CLOUDFLARE_TUNNEL_ORIGIN || '',
  ].filter(Boolean),
  credentials: true,
}));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, max: 60 }));

// ── HEALTH ────────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({
  status: 'OK', service: 'supplytheschools-xyz', port: PORT,
  stripe: !!stripe, supabase: !!process.env.SUPABASE_URL,
  timestamp: new Date().toISOString(),
}));

// ── TEACHER REQUEST SUBMISSION ────────────────────────────────────────────
app.post('/api/requests/submit', async (req, res) => {
  const {
    teacherName, schoolName, schoolEmail, gradeLevel,
    state, studentCount, description, supplyCategories = [],
    estimatedCost, titleI = false,
  } = req.body;

  if (!teacherName || !schoolName || !schoolEmail || !description) {
    return res.status(400).json({ error: 'teacherName, schoolName, schoolEmail, and description required' });
  }

  // Validate school email domain (must end in known edu/school patterns)
  const emailDomain = schoolEmail.split('@')[1] || '';
  const isLikelySchoolEmail = emailDomain.endsWith('.edu') || emailDomain.endsWith('.k12.us') || emailDomain.includes('schools') || emailDomain.includes('district') || emailDomain.includes('isd') || emailDomain.includes('usd');
  if (!isLikelySchoolEmail) {
    return res.status(400).json({ error: 'Please use your school-issued email address (.edu, .k12.us, or district email)' });
  }

  const requestHash = sha256(`${teacherName}|${schoolName}|${schoolEmail}|${description}|${Date.now()}`);
  const otsResult = await openTimestampAnchor(requestHash);

  let dbRecord = null;
  if (process.env.SUPABASE_URL) {
    const { data, error } = await supabase.from('school_requests').insert({
      teacher_name:      teacherName,
      school_name:       schoolName,
      school_email:      schoolEmail,
      grade_level:       gradeLevel,
      state,
      student_count:     parseInt(studentCount) || null,
      description,
      supply_categories: supplyCategories,
      estimated_cost:    parseFloat(estimatedCost) || null,
      title_i:           titleI,
      request_hash:      requestHash,
      ots_calendar:      otsResult?.calendar,
      status:            'pending_verification',
      funded_amount:     0,
    }).select().single();
    if (!error) dbRecord = data;
    else console.error('[STS-XYZ] Supabase insert error:', error.message);
  }

  res.status(201).json({
    success: true,
    requestId: dbRecord?.id || `STS-${Date.now().toString(36).toUpperCase()}`,
    message: 'Request received. School verification within 3-5 business days.',
    requestHash,
    otsResult,
    estimatedFulfillmentWindow: '1-2 weeks after verification',
    timestamp: new Date().toISOString(),
  });
});

// ── LIST ALL OPEN REQUESTS ────────────────────────────────────────────────
app.get('/api/requests', async (req, res) => {
  const { page = 1, limit = 20, state: stateFilter, status = 'verified' } = req.query;
  if (!process.env.SUPABASE_URL) return res.json({ requests: [], total: 0 });

  let query = supabase.from('school_requests')
    .select('*', { count: 'exact' })
    .eq('status', status)
    .order('created_at', { ascending: false })
    .range((page - 1) * limit, page * limit - 1);

  if (stateFilter) query = query.eq('state', stateFilter);

  const { data, error, count } = await query;
  if (error) return res.status(500).json({ error: error.message });

  res.json({ requests: data || [], total: count || 0, page: parseInt(page), limit: parseInt(limit) });
});

// ── SINGLE REQUEST ────────────────────────────────────────────────────────
app.get('/api/requests/:id', async (req, res) => {
  if (!process.env.SUPABASE_URL) return res.status(503).json({ error: 'Database not configured' });
  const { data, error } = await supabase.from('school_requests').select('*').eq('id', req.params.id).single();
  if (error) return res.status(404).json({ error: 'Request not found' });
  res.json(data);
});

// ── STRIPE PAYMENT INTENT ─────────────────────────────────────────────────
app.post('/api/donations/stripe/intent', async (req, res) => {
  if (!stripe) return res.status(503).json({ error: 'Stripe not configured — set STRIPE_SECRET_KEY in .env' });

  const { amountCents, currency = 'usd', donorEmail, requestId, metadata = {} } = req.body;
  if (!amountCents || amountCents < 100) return res.status(400).json({ error: 'amountCents must be >= 100 (minimum $1)' });

  const intent = await stripe.paymentIntents.create({
    amount: parseInt(amountCents),
    currency,
    receipt_email: donorEmail || undefined,
    metadata: {
      requestId: requestId || 'general',
      platform: 'supplytheschools.xyz',
      cert: IDENTITY.cert.slice(0, 30),
      ...metadata,
    },
    statement_descriptor: 'SUPPLY THE SCHOOLS',
  });

  res.json({ clientSecret: intent.client_secret, intentId: intent.id, amount: intent.amount, currency: intent.currency });
});

// ── STRIPE WEBHOOK ────────────────────────────────────────────────────────
async function handleStripeWebhook(req, res) {
  if (!stripe) return res.status(503).json({ error: 'Stripe not configured' });

  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) return res.status(400).json({ error: 'STRIPE_WEBHOOK_SECRET not configured' });

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error('[STS-XYZ] Stripe webhook signature failed:', err.message);
    return res.status(400).json({ error: `Webhook signature error: ${err.message}` });
  }

  if (event.type === 'payment_intent.succeeded') {
    const intent = event.data.object;
    const donationHash = sha256(`stripe|${intent.id}|${intent.amount}|${Date.now()}`);
    const otsResult = await openTimestampAnchor(donationHash);

    if (process.env.SUPABASE_URL) {
      await supabase.from('donations').insert({
        stripe_intent_id:  intent.id,
        amount_cents:      intent.amount,
        currency:          intent.currency,
        donor_email:       intent.receipt_email,
        request_id:        intent.metadata?.requestId,
        donation_hash:     donationHash,
        ots_calendar:      otsResult?.calendar,
        payment_method:    'stripe',
        status:            'completed',
      });

      // Update funded_amount on request if linked
      if (intent.metadata?.requestId) {
        await supabase.rpc('increment_funded_amount', {
          request_id_param:   intent.metadata.requestId,
          amount_cents_param: intent.amount,
        });
      }
    }
    console.log(`[STS-XYZ] Stripe donation completed: $${intent.amount / 100} — ${donationHash.slice(0, 16)}`);
  }

  res.json({ received: true });
}

// ── CRYPTO DONATION RECORD ────────────────────────────────────────────────
app.post('/api/donations/crypto/record', async (req, res) => {
  const { txHash, chain, amountUSD, fromAddr, requestId, note } = req.body;
  if (!txHash || !chain) return res.status(400).json({ error: 'txHash and chain required' });

  const donationHash = sha256(`crypto|${txHash}|${chain}|${amountUSD || 0}|${Date.now()}`);
  const otsResult = await openTimestampAnchor(donationHash);

  let dbRecord = null;
  if (process.env.SUPABASE_URL) {
    const { data } = await supabase.from('donations').insert({
      tx_hash: txHash, chain, amount_usd: parseFloat(amountUSD) || null,
      from_addr: fromAddr, request_id: requestId,
      donation_hash: donationHash, ots_calendar: otsResult?.calendar,
      ots_proof_hex: otsResult?.proofHex,
      payment_method: 'crypto', status: 'completed', note,
    }).select().single();
    dbRecord = data;
  }

  res.status(201).json({ success: true, donationHash, otsResult, dbRecord, timestamp: new Date().toISOString() });
});

// ── IMPACT STATS ──────────────────────────────────────────────────────────
app.get('/api/impact/stats', async (req, res) => {
  if (!process.env.SUPABASE_URL) {
    return res.json({
      totalRequests: 0, fulfilledRequests: 0, totalDonationsUSD: 0,
      studentsReached: 0, teachersServed: 0, statesReached: 0,
      note: 'Connect Supabase for live stats',
    });
  }
  const [reqStats, donStats] = await Promise.allSettled([
    supabase.from('school_requests').select('status, student_count, state, id', { count: 'exact' }),
    supabase.from('donations').select('amount_cents, amount_usd, payment_method'),
  ]);

  const requests  = reqStats.status  === 'fulfilled' ? reqStats.value.data  || [] : [];
  const donations = donStats.status === 'fulfilled' ? donStats.value.data || [] : [];

  const fulfilled = requests.filter(r => r.status === 'fulfilled');
  const states    = new Set(requests.map(r => r.state).filter(Boolean));
  const students  = fulfilled.reduce((s, r) => s + (r.student_count || 0), 0);
  const totalUSD  = donations.reduce((s, d) => s + (d.amount_cents ? d.amount_cents / 100 : (d.amount_usd || 0)), 0);

  res.json({
    totalRequests:    requests.length,
    fulfilledRequests: fulfilled.length,
    pendingRequests:  requests.filter(r => r.status === 'pending_verification').length,
    totalDonationsUSD: Math.round(totalUSD * 100) / 100,
    studentsReached:  students,
    teachersServed:   fulfilled.length,
    statesReached:    states.size,
    fetchedAt:        new Date().toISOString(),
  });
});

// ── SERVER BOOT ───────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════╗
║  SUPPLY THE SCHOOLS — xyz/tech/online Backend         ║
║  Port: ${PORT}  |  Stripe: ${stripe ? 'LIVE' : 'NOT_CONFIGURED'}                    ║
║  Domains: supplytheschools.xyz/.tech/.online          ║
╚═══════════════════════════════════════════════════════╝`);
});

module.exports = app;
