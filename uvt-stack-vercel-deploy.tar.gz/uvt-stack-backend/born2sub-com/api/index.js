/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BORN2SUB.COM — Vercel Serverless Entry Point
 * Wraps the full Express app as a single Vercel Function
 * All /api/* routes are handled here via a unified handler
 * © 2026 Cyrus Makai Schoonover | Born2Build, LLC
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

const express     = require('express');
const cors        = require('cors');
const helmet      = require('helmet');
const compression = require('compression');
const { createClient } = require('@supabase/supabase-js');

// Shared modules (path adjusted for Vercel's file resolution)
const path = require('path');
const sharedPath = path.join(__dirname, '../../shared');
const {
  runSovereignSession, openTimestampAnchor, getBtcBalance,
  getBaseBalance, sha256, TraceEngine, IDENTITY, WALLETS
} = require(sharedPath + '/utpl-hub');
const { runGates, quickHealthCheck } = require(sharedPath + '/bacccaas');
const { createSession, getSession, terminateSession } = require(sharedPath + '/avoc');

const app = express();

// ── Supabase client (lazy — only if env vars present) ────────────────────
const getSupabase = () => {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) return null;
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
};

// ── Stripe client (lazy) ──────────────────────────────────────────────────
const getStripe = () => {
  if (!process.env.STRIPE_SECRET_KEY) return null;
  return require('stripe')(process.env.STRIPE_SECRET_KEY);
};

// ── Middleware ────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(cors({
  origin: [
    'https://born2sub.com', 'https://www.born2sub.com',
    'https://born2sub.info', 'https://born2sub.online',
    'https://born2sub.store', 'https://born2sub.org',
  ],
  credentials: true,
}));

// Stripe webhook needs raw body — must come BEFORE express.json()
app.post('/api/stripe/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const stripe = getStripe();
  if (!stripe) return res.status(503).json({ error: 'Stripe not configured' });
  const sig     = req.headers['stripe-signature'];
  const secret  = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) return res.status(400).json({ error: 'STRIPE_WEBHOOK_SECRET not set' });
  let event;
  try { event = stripe.webhooks.constructEvent(req.body, sig, secret); }
  catch (err) { return res.status(400).json({ error: `Webhook error: ${err.message}` }); }
  if (event.type === 'payment_intent.succeeded') {
    const intent = event.data.object;
    const donationHash = sha256(`stripe|${intent.id}|${intent.amount}|${Date.now()}`);
    const otsResult = await openTimestampAnchor(donationHash);
    const supabase = getSupabase();
    if (supabase) {
      await supabase.from('donations').insert({
        stripe_intent_id: intent.id,
        amount_cents:     intent.amount,
        currency:         intent.currency,
        donor_email:      intent.receipt_email,
        donation_hash:    donationHash,
        ots_calendar:     otsResult?.calendar,
        payment_method:   'stripe',
        status:           'completed',
      });
    }
  }
  res.json({ received: true });
});

app.use(express.json({ limit: '10mb' }));

// ── HEALTH ────────────────────────────────────────────────────────────────
app.get('/api/health', async (req, res) => {
  const bacccaasHealth = await quickHealthCheck();
  res.json({
    status: 'OK',
    service: 'born2sub-com',
    runtime: 'vercel-serverless',
    cert: IDENTITY.cert,
    axiom: IDENTITY.axiom,
    bacccaas: bacccaasHealth,
    supabase:  !!process.env.SUPABASE_URL,
    anthropic: !!process.env.ANTHROPIC_API_KEY,
    stripe:    !!process.env.STRIPE_SECRET_KEY,
    timestamp: new Date().toISOString(),
  });
});

// ── WALLETS ───────────────────────────────────────────────────────────────
app.get('/api/wallets/balances', async (req, res) => {
  const [btc, base] = await Promise.allSettled([
    getBtcBalance(WALLETS.BTC_PERSONAL.addr),
    getBaseBalance(WALLETS.BASE.addr),
  ]);
  res.json({
    BTC_PERSONAL: btc.status  === 'fulfilled' ? btc.value  : null,
    BASE:         base.status === 'fulfilled' ? base.value : null,
    wallets:      WALLETS,
    fetchedAt:    new Date().toISOString(),
  });
});

// ── §2257 PERFORMER RECORD ────────────────────────────────────────────────
app.post('/api/compliance/submit-2257', async (req, res) => {
  const trace = new TraceEngine();
  trace.transition(0x30, 'SUBMIT_2257_INIT');

  const {
    performerId, legalName, dob, aliases = [],
    documentType, documentNumber, documentHash,
    consentHash, consentDate, consentVersion,
    walletAddr, traceSessionId, utplAcknowledged,
    platformId, contentType, verifiedAdult, ageVerificationMethod,
  } = req.body;

  const compliance = await runGates({
    performerId, legalName, dob, documentType, documentNumber, documentHash,
    consentHash, consentDate, consentVersion,
    walletAddr, traceSessionId, utplAcknowledged,
    platformId:            platformId || 'born2sub-com',
    contentType:           contentType || 'adult-content',
    consentVerified:       !!consentHash,
    verifiedAdult:         !!verifiedAdult,
    ageVerificationMethod: ageVerificationMethod || 'government_id',
  }, { anchorOnPass: true });

  trace.transition(0x06, `BACCCAAS_${compliance.pass ? 'PASS' : 'FAIL'}`);

  if (!compliance.pass) {
    return res.status(403).json({
      error: 'Compliance gates failed',
      determination: compliance.determination,
      criticalFail: compliance.criticalFail,
      gates: compliance.gates,
      complianceHash: compliance.complianceHash,
    });
  }

  const recordHash = sha256(JSON.stringify({ performerId, legalName, dob, documentHash, complianceHash: compliance.complianceHash, ts: Date.now() }));
  const otsResult  = compliance.otsResult || await openTimestampAnchor(recordHash);

  let dbRecord = null;
  const supabase = getSupabase();
  if (supabase) {
    const { data } = await supabase.from('performer_records').insert({
      performer_id: performerId, legal_name: legalName, dob, aliases,
      document_type: documentType, document_hash: documentHash,
      consent_hash: consentHash, consent_date: consentDate,
      compliance_hash: compliance.complianceHash, record_hash: recordHash,
      ots_calendar: otsResult?.calendar, ots_proof_hex: otsResult?.proofHex,
      trace_session_id: trace.sessionId, merkle_root: compliance.merkleRoot,
      wallet_addr: walletAddr || null, platform_id: platformId || 'born2sub-com',
    }).select().single();
    dbRecord = data;
  }

  trace.transition(0x09, 'RECORD_STORED');
  const merkle = await trace.merkleRoot();

  res.status(201).json({
    success: true,
    determination: compliance.determination,
    recordHash, complianceHash: compliance.complianceHash,
    merkleRoot: merkle, traceSessionId: trace.sessionId,
    otsResult, dbRecord: dbRecord ? { id: dbRecord.id, createdAt: dbRecord.created_at } : null,
    cert: IDENTITY.cert, timestamp: new Date().toISOString(),
  });
});

// ── COMPLIANCE STATUS ─────────────────────────────────────────────────────
app.get('/api/compliance/status/:userId', async (req, res) => {
  const supabase = getSupabase();
  if (!supabase) return res.json({ status: 'SUPABASE_NOT_CONFIGURED', userId: req.params.userId, records: [], score: 0 });
  const { data, error } = await supabase
    .from('performer_records').select('*').eq('user_id', req.params.userId)
    .order('created_at', { ascending: false }).limit(50);
  if (error) return res.status(500).json({ error: error.message });
  const compliant = data?.filter(r => r.compliance_hash) || [];
  res.json({
    userId: req.params.userId, totalRecords: data?.length || 0,
    compliantRecords: compliant.length,
    complianceScore: data?.length ? Math.round((compliant.length / data.length) * 100) : 0,
    records: data || [], cert: IDENTITY.cert, fetchedAt: new Date().toISOString(),
  });
});

// ── CREATOR ONBOARDING ────────────────────────────────────────────────────
app.post('/api/onboarding/creator', async (req, res) => {
  const { legalName, email, platformType, jurisdiction, contentVolume, walletAddr } = req.body;
  if (!legalName || !email) return res.status(400).json({ error: 'legalName and email required' });
  const onboardingHash = sha256(`${legalName}|${email}|${Date.now()}`);
  const otsResult = await openTimestampAnchor(onboardingHash);
  const supabase = getSupabase();
  let dbRecord = null;
  if (supabase) {
    const { data } = await supabase.from('creator_onboarding').insert({
      legal_name: legalName, email, platform_type: platformType || 'both',
      jurisdiction: jurisdiction || 'federal', content_volume: contentVolume,
      wallet_addr: walletAddr || null, onboarding_hash: onboardingHash,
      ots_calendar: otsResult?.calendar, status: 'pending_review',
    }).select().single();
    dbRecord = data;
  }
  res.status(201).json({
    success: true, onboardingHash, otsResult,
    applicationId: dbRecord?.id || `B2S-${Date.now().toString(36).toUpperCase()}`,
    message: 'Creator onboarding initiated. TRACE provisioning within 24 hours.',
    timestamp: new Date().toISOString(),
  });
});

// ── AVOC SESSIONS ─────────────────────────────────────────────────────────
app.post('/api/avoc/session/create', async (req, res) => {
  const { walletAddr, walletNetwork, consentHash } = req.body;
  const userId = req.headers['x-user-id'] || req.body.userId;
  if (!walletAddr || !userId) return res.status(400).json({ error: 'walletAddr and userId required' });
  const session   = createSession({ walletAddr, walletNetwork, userId, domain: 'born2sub-com', consentHash });
  const handshake = await session.initHandshake();
  res.status(201).json({ success: true, session: session.toJSON(), handshake });
});

app.get('/api/avoc/session/:id', (req, res) => {
  const s = getSession(req.params.id);
  if (!s) return res.status(404).json({ error: 'Session not found' });
  res.json(s.toJSON());
});

app.post('/api/avoc/session/terminate', async (req, res) => {
  const sessionId = req.headers['x-avoc-session'] || req.body.sessionId;
  if (!sessionId) return res.status(400).json({ error: 'sessionId required' });
  try {
    const result = await terminateSession(sessionId, req.body.reason || 'USER_REQUESTED');
    res.json({ success: true, ...result });
  } catch (e) { res.status(404).json({ error: e.message }); }
});

// ── AI ANALYSIS ───────────────────────────────────────────────────────────
app.post('/api/analysis/ai', async (req, res) => {
  const { query, domain = 'ip', jurisdictions = ['Federal'] } = req.body;
  if (!query) return res.status(400).json({ error: 'query required' });
  const result = await runSovereignSession({ query, domain, jurisdictions });
  res.json(result);
});

// ── Vercel export ─────────────────────────────────────────────────────────
module.exports = app;
