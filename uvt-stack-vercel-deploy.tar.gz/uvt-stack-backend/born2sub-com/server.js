/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BORN2SUB.COM — Backend Server (Port 3001)
 * Adult Content Creator Compliance Platform — ACCCaaS + AVOC
 * © 2026 Cyrus Makai Schoonover | Born2Build, LLC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * DOMAINS SERVED:
 *   - born2sub.com (primary)
 *   - born2sub.info, born2sub.online, born2sub.store, born2sub.org (IONOS)
 *
 * ENDPOINTS:
 *   POST /api/compliance/submit-2257       ← Performer record submission
 *   POST /api/compliance/verify            ← Run BACCCaaS gates (subset or all)
 *   GET  /api/compliance/status/:userId    ← Creator compliance dashboard data
 *   POST /api/onboarding/creator           ← New creator registration
 *   POST /api/avoc/session/create          ← AVOC session init
 *   POST /api/avoc/session/terminate       ← AVOC session close + BTC anchor
 *   GET  /api/avoc/session/:id             ← Session status
 *   POST /api/analysis/ai                  ← Claude AI compliance analysis
 *   GET  /api/health                       ← Health check
 *   GET  /api/wallets/balances             ← Live BTC + Base balances
 */

'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const express       = require('express');
const cors          = require('cors');
const helmet        = require('helmet');
const compression   = require('compression');
const rateLimit     = require('express-rate-limit');
const morgan        = require('morgan');
const { createClient } = require('@supabase/supabase-js');

const { runSovereignSession, openTimestampAnchor, getBtcBalance, getBaseBalance, sha256, TraceEngine, IDENTITY, WALLETS } = require('../shared/utpl-hub');
const { runGates, bacccaasMiddleware, quickHealthCheck } = require('../shared/bacccaas');
const { createSession, getSession, terminateSession, listActiveSessions, avocSessionMiddleware } = require('../shared/avoc');

const app  = express();
const PORT = process.env.PORT_B2S_COM || 3001;
const supabase = createClient(
  process.env.SUPABASE_URL    || '',
  process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY || ''
);

// ── MIDDLEWARE ────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(cors({
  origin: [
    'https://born2sub.com', 'https://www.born2sub.com',
    'https://born2sub.info', 'https://born2sub.online',
    'https://born2sub.store', 'https://born2sub.org',
    'http://localhost:3000', 'http://localhost:3001',
    process.env.CLOUDFLARE_TUNNEL_ORIGIN || '',
  ].filter(Boolean),
  credentials: true,
}));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100, standardHeaders: true, legacyHeaders: false });
app.use('/api/', limiter);

// ── HEALTH ────────────────────────────────────────────────────────────────
app.get('/api/health', async (req, res) => {
  const bacccaasHealth = await quickHealthCheck();
  res.json({
    status: 'OK',
    service: 'born2sub-com',
    port: PORT,
    cert: IDENTITY.cert,
    axiom: IDENTITY.axiom,
    bacccaas: bacccaasHealth,
    supabase: !!process.env.SUPABASE_URL,
    anthropic: !!process.env.ANTHROPIC_API_KEY,
    timestamp: new Date().toISOString(),
  });
});

// ── WALLET BALANCES ───────────────────────────────────────────────────────
app.get('/api/wallets/balances', async (req, res) => {
  const [btc, base] = await Promise.allSettled([
    getBtcBalance(WALLETS.BTC_PERSONAL.addr),
    getBaseBalance(WALLETS.BASE.addr),
  ]);
  res.json({
    BTC_PERSONAL:  btc.status  === 'fulfilled' ? btc.value  : null,
    BASE:          base.status === 'fulfilled' ? base.value : null,
    wallets:       WALLETS,
    fetchedAt:     new Date().toISOString(),
  });
});

// ── §2257 PERFORMER RECORD SUBMISSION ────────────────────────────────────
app.post('/api/compliance/submit-2257', async (req, res) => {
  const trace = new TraceEngine();
  trace.transition(0x30, 'SUBMIT_2257_INIT');

  const {
    performerId, legalName, dob, aliases = [],
    documentType, documentNumber, documentHash,
    consentHash, consentDate, consentVersion,
    walletAddr, traceSessionId, utplAcknowledged,
    platformId, contentType, verifiedAdult, ageVerificationMethod,
  } = req.body;

  // Run full BACCCaaS (all 7 gates)
  const compliance = await runGates({
    performerId, legalName, dob, aliases,
    documentType, documentNumber, documentHash,
    consentHash, consentDate, consentVersion,
    walletAddr, traceSessionId,
    utplAcknowledged,
    platformId: platformId || 'born2sub-com',
    contentType: contentType || 'adult-content',
    consentVerified: !!consentHash,
    verifiedAdult: !!verifiedAdult,
    ageVerificationMethod: ageVerificationMethod || 'government_id',
    exchangeForValue: req.body.exchangeForValue,
    thirdPartyArranged: req.body.thirdPartyArranged,
  }, { anchorOnPass: process.env.NODE_ENV === 'production' });

  trace.transition(0x06, `BACCCAAS_${compliance.pass ? 'PASS' : 'FAIL'}`);

  if (!compliance.pass) {
    return res.status(403).json({
      error: 'Compliance gates failed',
      determination: compliance.determination,
      criticalFail: compliance.criticalFail,
      gates: compliance.gates,
      complianceHash: compliance.complianceHash,
    });
  }

  // Anchor to Bitcoin
  const recordHash = sha256(JSON.stringify({ performerId, legalName, dob, documentHash, complianceHash: compliance.complianceHash, ts: Date.now() }));
  trace.transition(0x03, 'BTC_ANCHOR');
  const otsResult = compliance.otsResult || await openTimestampAnchor(recordHash);

  // Store to Supabase
  let dbRecord = null;
  if (process.env.SUPABASE_URL) {
    const { data, error } = await supabase.from('performer_records').insert({
      performer_id:     performerId,
      legal_name:       legalName,
      dob,
      aliases,
      document_type:    documentType,
      document_hash:    documentHash,
      consent_hash:     consentHash,
      consent_date:     consentDate,
      compliance_hash:  compliance.complianceHash,
      record_hash:      recordHash,
      ots_calendar:     otsResult?.calendar,
      ots_proof_hex:    otsResult?.proofHex,
      trace_session_id: trace.sessionId,
      merkle_root:      compliance.merkleRoot,
      wallet_addr:      walletAddr || null,
      platform_id:      platformId || 'born2sub-com',
    }).select().single();
    if (!error) dbRecord = data;
    else console.error('[B2S-COM] Supabase insert error:', error.message);
  }

  trace.transition(0x09, 'RECORD_STORED');
  const merkle = await trace.merkleRoot();

  res.status(201).json({
    success: true,
    determination: compliance.determination,
    recordHash,
    complianceHash: compliance.complianceHash,
    merkleRoot: merkle,
    traceSessionId: trace.sessionId,
    otsResult,
    dbRecord: dbRecord ? { id: dbRecord.id, createdAt: dbRecord.created_at } : null,
    cert: IDENTITY.cert,
    timestamp: new Date().toISOString(),
  });
});

// ── COMPLIANCE STATUS DASHBOARD ───────────────────────────────────────────
app.get('/api/compliance/status/:userId', async (req, res) => {
  const { userId } = req.params;
  if (!process.env.SUPABASE_URL) {
    return res.json({ status: 'SUPABASE_NOT_CONFIGURED', userId, records: [], score: 0 });
  }
  const { data: records, error } = await supabase
    .from('performer_records')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) return res.status(500).json({ error: error.message });

  const compliant = records?.filter(r => r.compliance_hash) || [];
  res.json({
    userId,
    totalRecords: records?.length || 0,
    compliantRecords: compliant.length,
    complianceScore: records?.length ? Math.round((compliant.length / records.length) * 100) : 0,
    records: records || [],
    cert: IDENTITY.cert,
    fetchedAt: new Date().toISOString(),
  });
});

// ── CREATOR ONBOARDING ────────────────────────────────────────────────────
app.post('/api/onboarding/creator', async (req, res) => {
  const { legalName, email, platformType, jurisdiction, contentVolume, walletAddr } = req.body;
  if (!legalName || !email) return res.status(400).json({ error: 'legalName and email required' });

  const onboardingHash = sha256(`${legalName}|${email}|${Date.now()}`);
  const otsResult = await openTimestampAnchor(onboardingHash);

  let dbRecord = null;
  if (process.env.SUPABASE_URL) {
    const { data, error } = await supabase.from('creator_onboarding').insert({
      legal_name:       legalName,
      email,
      platform_type:    platformType || 'both',
      jurisdiction:     jurisdiction || 'federal',
      content_volume:   contentVolume,
      wallet_addr:      walletAddr || null,
      onboarding_hash:  onboardingHash,
      ots_calendar:     otsResult?.calendar,
      status:           'pending_review',
    }).select().single();
    if (!error) dbRecord = data;
  }

  res.status(201).json({
    success: true,
    message: 'Creator onboarding initiated. TRACE provisioning within 24 hours.',
    onboardingHash,
    otsResult,
    applicationId: dbRecord?.id || `B2S-${Date.now().toString(36).toUpperCase()}`,
    nextSteps: [
      'Verify your .edu or professional email within 24 hours',
      'Upload government-issued ID for §2257 compliance',
      'Sign AVOC consent document',
      'Receive ACCCaaS dashboard credentials',
    ],
    timestamp: new Date().toISOString(),
  });
});

// ── AVOC SESSION ENDPOINTS ────────────────────────────────────────────────
app.post('/api/avoc/session/create', async (req, res) => {
  const { walletAddr, walletNetwork, consentHash } = req.body;
  if (!walletAddr) return res.status(400).json({ error: 'walletAddr required' });

  const userId = req.headers['x-user-id'] || req.body.userId;
  if (!userId) return res.status(400).json({ error: 'userId required (X-User-Id header or body)' });

  const session = createSession({ walletAddr, walletNetwork, userId, domain: 'born2sub-com', consentHash });
  const handshake = await session.initHandshake();

  res.status(201).json({
    success: true,
    session: session.toJSON(),
    handshake,
    instructions: 'Include X-AVOC-Session header in subsequent requests',
  });
});

app.get('/api/avoc/session/:id', (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json(session.toJSON());
});

app.post('/api/avoc/session/terminate', async (req, res) => {
  const sessionId = req.headers['x-avoc-session'] || req.body.sessionId;
  if (!sessionId) return res.status(400).json({ error: 'sessionId required' });
  try {
    const result = await terminateSession(sessionId, req.body.reason || 'USER_REQUESTED');
    res.json({ success: true, ...result });
  } catch (e) {
    res.status(404).json({ error: e.message });
  }
});

// ── CLAUDE AI ANALYSIS ────────────────────────────────────────────────────
app.post('/api/analysis/ai', async (req, res) => {
  const { query, domain = 'ip', jurisdictions = ['Federal'] } = req.body;
  if (!query) return res.status(400).json({ error: 'query required' });

  const sessionResult = await runSovereignSession({ query, domain, jurisdictions });
  res.json(sessionResult);
});

// ── SERVER BOOT ───────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════╗
║  BORN2SUB.COM — ACCCaaS / §2257 Compliance Server     ║
║  Port: ${PORT}  |  NODE_ENV: ${(process.env.NODE_ENV || 'development').padEnd(11)}              ║
║  CERT: ${IDENTITY.cert.slice(0, 35)}…  ║
║  "${IDENTITY.axiom}"                    ║
║  Domains: born2sub.com / .info / .online / .store / .org ║
╚═══════════════════════════════════════════════════════╝`);
});

module.exports = app;
